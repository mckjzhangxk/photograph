These are the exercises that we used in 2020 for our lecture
"Mobile Sensing and Robotics 1" taught at the University of Bonn. 

The intention of sharing the exercises is to allow students to 
study and practice on their own and get a deeper understanding 
of the topic. 

For the exercises, you need to use Python and Jupyter notebooks.
Please note that we cannot provide any support for the exercises.
