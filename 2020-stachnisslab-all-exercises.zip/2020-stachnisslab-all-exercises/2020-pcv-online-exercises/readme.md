These are the exercises that we arranged for the online course
"Photogrammetric Computer Vision". The individual exercises stem 
from related courses taught at the University of Bonn. Thus, the 
numbering of the exercises within the notebook files are not 
consistent; but in this way, files are identical for identical 
exercises.

The intention of sharing the exercises is to allow students to 
study and practice on their own and get a deeper understanding 
of the topic. 

For the exercises, you need to use Python and Jupyter notebooks.
Please note that we cannot provide any support for the exercises.
